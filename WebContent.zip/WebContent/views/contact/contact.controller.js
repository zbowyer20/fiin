(function() {
	'use strict';
	
	angular
		.module('pwapp')
		.controller('ContactController', ContactController);
	
	
	/** @ngInject */
	function ContactController($scope) {
	}
	
})();
